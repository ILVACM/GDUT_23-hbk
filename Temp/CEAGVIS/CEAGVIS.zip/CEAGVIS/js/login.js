
// 获取down盒子和login-box盒子的元素
const downBox = document.querySelector('.down');
const loginBox = document.querySelector('.login-box');

// 为down盒子添加点击事件监听器
downBox.addEventListener('click', function () {
    // 切换login-box的显示状态
    if (loginBox.style.display === 'none' || loginBox.style.display === '') {
        loginBox.style.display = 'block'; // 显示login-box
    } else {
        loginBox.style.display = 'none'; // 隐藏login-box
    }
});

// 点击文档其他地方时隐藏login-box
document.addEventListener('click', function (event) {
    if (!loginBox.contains(event.target) && !downBox.contains(event.target)) {
        loginBox.style.display = 'none'; // 隐藏login-box
    }
});

// 点击弹出去登陆盒子
// 点击立即登录，隐藏去登录框
// 获取元素
const login = document.querySelector('.login-box');
const toLoginBoxes = document.querySelectorAll('.to-login');
const realLoginBox = document.querySelector('.real-login-box');
// 获取类名为 'register' 的盒子
const registerBox = document.querySelector('.register');
const closeBoxes = document.querySelectorAll('.close');

// 为每个 .to-login 盒子添加点击事件监听器
toLoginBoxes.forEach(box => {
    box.addEventListener('click', function () {
        login.style.display = 'none';
        realLoginBox.style.display = 'block';
    });
});

// 为每个 .close 盒子添加点击事件监听器
closeBoxes.forEach(box => {
    box.addEventListener('click', function () {
        realLoginBox.style.display = 'none';
        registerBox.style.display = 'none'
    });
});





// 获取三个span元素
const tabs = document.querySelectorAll('.login-box-tabs span');
// 获取login-box-code、login-box-key和login-box-bottom元素
const codeBox = document.querySelector('.login-box-code');
const keyBox = document.querySelector('.login-box-key');
const bottomBox = document.querySelector('.login-box-bottom');

// 初始化变量，用于跟踪当前显示的内容框
let currentBox = codeBox;

// 遍历每个span元素
tabs.forEach((tab, index) => {
    // 给每个span元素添加点击事件监听器
    tab.addEventListener('click', () => {
        // 如果点击的是第一个span，并且当前显示的不是login-box-code，则显示login-box-code，隐藏login-box-key
        if (index === 0 && currentBox !== codeBox) {
            codeBox.style.display = 'flex';
            keyBox.style.display = 'none';
            bottomBox.style.display = 'flex'; // 显示 login-box-bottom
            currentBox = codeBox;
        }
        // 如果点击的不是第一个span，并且当前显示的不是login-box-key，则显示login-box-key，隐藏login-box-code
        else if (index !== 0 && currentBox !== keyBox) {
            codeBox.style.display = 'none';
            keyBox.style.display = 'block';
            bottomBox.style.display = 'none'; // 隐藏 login-box-bottom
            currentBox = keyBox;
        }

        // 移除所有span元素的底部边框样式
        tabs.forEach(tab => {
            tab.style.borderBottom = 'none';
        });

        // 添加点击的span元素的底部边框样式
        tab.style.borderBottom = '2px solid #31afff';
    });
});
// -------------------------------------------------------------------




// 点击图标看决定是否显示密码
document.addEventListener('DOMContentLoaded', function () {
    const showPasswordBoxes = document.querySelectorAll('.show-password');
    const passwordBoxes = document.querySelectorAll('.pass-word');

    showPasswordBoxes.forEach(function (showPasswordBox) {
        showPasswordBox.addEventListener('click', function () {
            // 切换密码输入框的类型
            passwordBoxes.forEach(function (passwordBox) {
                if (passwordBox.type === 'password') {
                    passwordBox.type = 'text';
                } else {
                    passwordBox.type = 'password';
                }
            });
        });
    });
});
// -----------------------------------------------------------------------------





// 点击去注册就弹出注册盒子，隐藏注册盒子
// 获取所有类名为 'to-register' 的盒子
const toRegisterBoxes = document.querySelectorAll('.to-register');

// 确保所有需要的盒子都存在
if (registerBox && realLoginBox) {
    // 为每个 'to-register' 盒子添加点击事件监听器
    toRegisterBoxes.forEach(box => {
        box.addEventListener('click', () => {
            // 显示 'register' 盒子
            registerBox.style.display = 'block';
            // 隐藏 'real-login-box' 盒子
            realLoginBox.style.display = 'none';
        });
    });
}