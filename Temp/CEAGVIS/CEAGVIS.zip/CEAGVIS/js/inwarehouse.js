const detailsDiv = document.getElementById('details');
const contentDiv = document.getElementById('boxContent');
const highlight = document.querySelectorAll('.details-nav li');
var isSwitchWareHouse = 0

//盒子的显现与隐藏
function switchBox(hiddenBox, visibleBox) {
    console.log(hiddenBox.style.display)
    console.log(visibleBox.style.display)
    if (hiddenBox.style.display === 'none') {
        visibleBox.style.display = 'none';
        hiddenBox.style.display = 'flex';
    }
}
function goBack() {
    console.log('交换');
    switchBox(contentDiv, detailsDiv)
}
//导航的高亮
function handleHighlight(type) {
    //选择仓库数据
    if (!isSwitchWareHouse) {
        console.log('选择仓库数据')
        console.log(type)
        document.querySelectorAll('.details-nav li').forEach(item => {
            //移除所有类名
            item.classList.remove('selected')
            if (item.getAttribute('data-type') === type) {
                console.log(item)
                //给对应的li添加类名
                item.classList.add('selected')
                console.log(item)
            }
        })
    }
    //选择不同仓库
    else {
        console.log('选择不同仓库')
        document.querySelectorAll('.nav li').forEach(item => {
            //移除所有类名
            item.classList.remove('selected')
            if (item.getAttribute('data-type') === type) {
                //给对应的li添加类名
                item.classList.add('selected')
            }
        })
    }
}
document.querySelectorAll('.nav li').forEach(item => {
    item.addEventListener('click', (event) => {
        const type = event.currentTarget.getAttribute('data-type')
        switch (type) {
            case '1': isSwitchWareHouse = 1; handleHighlight(type)
                //连接口调用仓库1数据
                ; break;
            case '2': isSwitchWareHouse = 1; handleHighlight(type)
                //连接口调用仓库2数据
                ; break;
            case '3': isSwitchWareHouse = 1; handleHighlight(type)
                //连接口调用仓库3数据
                ; break;
        }

    })
})
document.querySelectorAll('.element').forEach(item => {
    item.addEventListener('click', (event) => {
        console.log('点击了')
        const type = event.currentTarget.getAttribute('data-type');
        console.log(type)
        switch (type) {
            case 'temperature': switchBox(detailsDiv, contentDiv); handleHighlight(type)
                //连接口调出温度的数据
                ; break;
            case 'humidity': switchBox(detailsDiv, contentDiv); handleHighlight(type);
                //连接口调出湿度的数据
                break;
            case 'hardware': switchBox(detailsDiv, contentDiv); handleHighlight(type);
                //连接口调出系统硬件的数据
                break;
        }
    })
})


function go(start, end) {
    const circleLeft = document.querySelector('.left-circle')
    const circleRight = document.querySelector('.right-circle')
    const number = document.querySelector('.number')
    function formatDegreeLeft(percent) {
        // 封装左边圆角度
        return `rotate(${-225 + (360 / 100 * percent)}deg)`  // 旋转角度要与定时器相对应，我这使用的是6s转动360度
    }
    function formatDegreeRight(percent) {
        // 封装右边圆角度
        return `rotate(${-45 + (360 / 100 * percent)}deg)`
    }
    function setRotateLeft(node, percent) {
        // 设置旋转左圆的角度
        node.style.transform = formatDegreeLeft(percent)
    }
    function setRotateRight(node, percent) {
        // 设置旋转右圆的角度
        node.style.transform = formatDegreeRight(percent)
    }
    let percent = start  //百分比
    let t = setInterval(() => {
        percent++
        if (percent >= 0 && percent <= 50) { //如果百分比在50以内旋转右边圆
            setRotateRight(circleRight, percent)
        } else if (percent > 50 && percent <= 100) { //如果百分比在50以上，固定右半边圆和旋转左半边圆
            circleRight.style.transform = 'rotate(135deg)'
            setRotateLeft(circleLeft, percent)
        }
        number.textContent = percent + '℃'
        if (percent >= end) {
            clearInterval(t)
            if (percent >= 100) {
                number.textContent = '加载完成'
            }
        }
    }, 60)

}

go(0, 29)  // 进度0 到进度29
function go2(start, end) {
    const circleLeft2 = document.querySelector('.left-circle2')
    const circleRight2 = document.querySelector('.right-circle2')
    const number2 = document.querySelector('.number2')
    function formatDegreeLeft2(percent) {
        // 封装左边圆角度
        return `rotate(${-225 + (360 / 100 * percent)}deg)`  // 旋转角度要与定时器相对应，我这使用的是6s转动360度
    }
    function formatDegreeRight2(percent) {
        // 封装右边圆角度
        return `rotate(${-45 + (360 / 100 * percent)}deg)`
    }
    function setRotateLeft2(node, percent) {
        // 设置旋转左圆的角度
        node.style.transform = formatDegreeLeft2(percent)
    }
    function setRotateRight2(node, percent) {
        // 设置旋转右圆的角度
        node.style.transform = formatDegreeRight2(percent)
    }
    let percent = start  //百分比
    let t = setInterval(() => {
        percent++
        if (percent >= 0 && percent <= 50) { //如果百分比在50以内旋转右边圆
            setRotateRight2(circleRight2, percent)
        } else if (percent > 50 && percent <= 100) { //如果百分比在50以上，固定右半边圆和旋转左半边圆
            circleRight2.style.transform = 'rotate(135deg)'
            setRotateLeft2(circleLeft2, percent)
        }
        number2.textContent = percent + 'RH'
        if (percent >= end) {
            clearInterval(t)
            if (percent >= 100) {
                number2.textContent = '加载完成'
            }
        }
    }, 60)

}
go2(0, 75)